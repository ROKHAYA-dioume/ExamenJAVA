import java.util.ArrayList;

public class Service {
    private final int TAILLE = 100;
    private Local tableLocal[] = new Local[TAILLE];
    private int tailleReelleLocal;
    private Reservation tableReservation[] = new Reservation[TAILLE];
    private int tailleReellePr;
    private Client tableClient[] = new Client[TAILLE];
    private int tailleReellec;
    private Chambre tableChambre[] = new Chambre[TAILLE];
    private int tailleReellech;
    private Appartement tableAppartement[] = new Appartement[TAILLE];
    private int tailleReellea;
    private int idReservation = 1;
    private int idLocal = 1;

    public void addLocal(Local local) {
        if (tailleReelleLocal < TAILLE) {
            tableLocal[tailleReelleLocal] = local;
            tailleReelleLocal++;
        } else {
            System.out.println("Le tableau est plein");
        }

    }

    public void listerLocal() {
        for (Local element : tableLocal) {
            if (element != null) {
                System.out.println(element.afficher());
                System.out.println("");
            }

        }
    }

    public Local[] listerAllLocal() {
        return tableLocal;
    }

    public void listerIdLocal() {
        for (Local element : tableLocal) {
            if (element != null) {
                System.out.print(element.getId() + " || ");
            }

        }
        System.out.println("");
    }

    public Local searchLocal(String ref) {
        for (Local local : tableLocal) {
            if (local != null) {
                if (local.getRef() == ref) {
                    return local;
                }
            }
        }
        return null;
    }

    public void addReservation(Reservation r) {
        if (tailleReellePr < TAILLE) {
            tableReservation[tailleReellePr] = r;
            r.setId(idReservation);
            idReservation++;
            tailleReellePr++;
        } else {
            System.out.println("Le tableau est plein");
        }
    }

    public void listerReservation() {
        for (Reservation element : tableReservation) {
            if (element != null) {
                System.out.println(element.afficher());
                System.out.println("");
            }

        }
    }

    public Client searchClient(int nci) {
        for (Client client : tableClient) {
            if (client != null) {
                if (client.getNci() == nci) {
                    return client;
                }
            }
        }
        return null;
    }

    public Local trouverLocal(int id) {
        for (Local local : tableLocal) {
            if (local != null) {
                if (local.getId() == id) {
                    return local;
                }
            }
        }
        return null;
    }

    public void trouverClientReserve(int nci) {
        for (Reservation r : tableReservation) {
            if (r != null) {
                if (r.getClient().getNci() == nci) {
                    System.out.println(r.affiche());
                }
            }
        }

    }

    public void addClient(Client client) {
        if (tailleReellec < TAILLE) {
            tableClient[tailleReellec] = client;
            tailleReellec++;
        } else {
            System.out.println("Le tableau est plein");
        }

    }

    public void listerClient() {
        for (Client element : tableClient) {
            if (element != null) {
                System.out.println(element.affiche());
                System.out.println("");
            }

        }
    }

    public void addChambre(Chambre c) {
        if (tailleReellech < TAILLE) {
            tableChambre[tailleReellech] = c;
            c.setId(idLocal);
            idLocal++;
            tailleReellech++;
        } else {
            System.out.println("Le tableau est plein");
        }

    }

    public void listerChambre() {
        for (Chambre element : tableChambre) {
            if (element != null) {
                System.out.println(element.affiche());
                System.out.println("");
            }

        }
    }

    public void listerChambreDispo() {
        ArrayList<Reservation> chambreReserve = new ArrayList<>();
        for (Chambre element : tableChambre) {
            if (element != null) {
                for (Reservation r : element.getTableReservation()) {
                    if (r != null) {
                        chambreReserve.add(r);
                    }
                }
                if (chambreReserve.size() == 0) {
                    System.out.println(element.affiche());
                    System.out.println("");
                }
            }

        }
    }

    public void addAppartement(Appartement a) {
        if (tailleReellea < TAILLE) {
            tableAppartement[tailleReellea] = a;
            a.setId(idLocal);
            idLocal++;
            tailleReellea++;
        } else {
            System.out.println("Le tableau est plein");
        }

    }

    public void listerAppartement() {
        for (Appartement element : tableAppartement) {
            if (element != null) {
                System.out.println(element.affiche());
                System.out.println("");
            }

        }
    }

    public void listerAppartDispo() {
        ArrayList<Reservation> appartReserve = new ArrayList<>();
        for (Appartement element : tableAppartement) {
            if (element != null) {
                for (Reservation r : element.getTableReservation()) {
                    if (r != null) {
                        appartReserve.add(r);
                    }
                }

                if (appartReserve.size() == 0) {
                    System.out.println(element.affiche());
                    System.out.println("");
                }
            }

        }
    }
}
