import java.time.LocalDate;
import java.util.Scanner;
import java.time.format.DateTimeFormatter;

//JsonParser parser = new JsonParser;

public class Main {
    private static Reservation reservation;
    public static Scanner scanner = new Scanner(System.in);

    public static int menu() {
        int choix;
        System.out.println("Menu" + "\n 1-Ajouter un local" + "\n 2-Lister locaux par type"
                + "\n 3-Lister locaux reserver par un client" + "\n 4-Detail d'un local" + "\n 5-Faire une reservation"
                + "\n 6-Annuler la reservation" + "\n 7-Lister locaux disponible" + "\n 8-Quitter");
        System.out.print("Faites votre choix : ");
        choix = scanner.nextInt();

        return choix;

    }

    public static void main(String[] args) {
        Service service = new Service();
        int choix;
        Local local;
        do {
            System.out.println("Menu" + "\n 1-Ajouter un local" + "\n 2-Lister locaux par type"
                    + "\n 3-Lister locaux reserver par un client" + "\n 4-Detail d'un local"
                    + "\n 5-Faire une reservation" + "\n 6-Annuler la reservation" + "\n 7-Lister locaux disponible"
                    + "\n 8-Quitter");
            System.out.print("Faites votre choix : ");
            choix = scanner.nextInt();

            Client client;
            switch (choix) {
                case 1:
                    System.out.println("     Ajout d'un local       ");

                    int typeLocaux;
                    do {
                        System.out.println("Entrer le type  : " + "\n 1- Appartement" + "\n 2- Chambre");
                        typeLocaux = scanner.nextInt();
                    } while (typeLocaux != 2 && typeLocaux != 1);

                    if (typeLocaux == 1) {
                        System.out.print("Entrer le nombre de piece : ");
                        int nbrPiece = scanner.nextInt();
                        local = new Appartement();
                        ((Appartement) local).setNbrPiece(nbrPiece);
                        service.addAppartement((Appartement) local);

                    } else {
                        System.out.print("Entrer la dimension : ");
                        int dimension = scanner.nextInt();
                        local = new Chambre();
                        ((Chambre) local).setDimension(dimension);
                        service.addChambre((Chambre) local);

                    }
                    System.out.print("Entrer la localisation : ");
                    String localisation = scanner.next();
                    System.out.print("Entrer le prix : ");
                    int prix = scanner.nextInt();
                    System.out.print("Entrer le taux : ");
                    int tauxLoc = scanner.nextInt();
                    local.setLocalisation(localisation);
                    local.setPrix(prix);
                    float tauxLocFl = tauxLoc;
                    local.setTauxLoc(tauxLocFl);
                    service.addLocal(local);
                    break;
                case 2:
                    System.out.print(
                            "================================ Appartement ================================ \n        ");
                    service.listerAppartement();

                    System.out.println("\n");
                    System.out.print("================================ Chambre ================================ \n");
                    service.listerChambre();
                    break;
                case 3:
                    System.out.println("===========  Liste des clients  ===========");
                    service.listerClient();
                    System.out.println("Veuillez saisir le nci du client:");
                    int nciClient = scanner.nextInt();
                    service.trouverClientReserve(nciClient);

                    break;
                case 4:
                    System.out.println("Chosir l'ID du Local");
                    System.out.print(
                            "================================ Liste Local ================================    \n     ");
                    service.listerIdLocal();
                    Local[] tablesLocal = service.listerAllLocal();
                    int idLoc = scanner.nextInt();
                    for (Local loc : tablesLocal) {
                        if (loc != null) {
                            if (loc.getId() == idLoc) {
                                System.out.println(loc.afficher());
                            }
                        }
                    }

                    System.out.println("");

                    break;
                case 5:
                    System.out.print("Entrer le nci : ");
                    int nci = scanner.nextInt();
                    client = service.searchClient(nci);
                    if (client == null) {
                        System.out.print("Entrer le nom complet du client : ");
                        String nomComplet = scanner.nextInt();
                        client = service.searchClient(nci);
                        
                        System.out.print("Entrer le mail du client : ");
                        String email = scanner.next();
                        System.out.print("Entrer l'adresse du client : ");
                        String adresse = scanner.next();
                        System.out.print("Entrer le numero du client : ");
                        int tel = scanner.nextInt();
                        client = new Client(nci, nomComplet, email, adresse, tel);
                        service.addClient(client);

                    }
                    System.out.println("        Faire une reservation       ");

                    System.out.println("Saisir l'ID du Local");
                    System.out.print(
                            "================================ Appartement ================================    \n     ");
                    service.listerAppartement();

                    System.out.println("\n");
                    System.out.print("================================ Chambre ================================ \n ");
                    service.listerChambre();

                    int idLocal = scanner.nextInt();
                    Local localClient = service.trouverLocal(idLocal);

                    System.out.print("Entrer la date de reservation : dd/MM/yyyy ");
                    // String date = scanner.nextLine();
                    String txtDate = scanner.next();
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                    LocalDate date = LocalDate.parse(txtDate, formatter);
                    System.out.print("Entrer la duree de reservation : ");
                    String duree = scanner.next();
                    reservation = new Reservation(date, duree, client, localClient);
                    reservation.setEtat("reserve");
                    client.setTableReservation(reservation);
                    localClient.setTableReservation(reservation);
                    service.addReservation(reservation);
                    break;
                case 6:

                    break;
                case 7:
                    System.out.print("================= Locaux disponibles ================== \n        ");

                    System.out.print(
                            "================================ Appartement ================================ \n        ");
                    service.listerAppartDispo();

                    System.out.println("\n");
                    System.out.print("================================ Chambre ================================ \n");
                    service.listerChambreDispo();

                    break;
                case 8:
                    break;
                default:
            }
        } while (choix != 8);
    }
}