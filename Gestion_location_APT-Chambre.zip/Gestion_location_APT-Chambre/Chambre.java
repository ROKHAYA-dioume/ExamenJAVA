public class Chambre extends Local {
    private float dimension;

    public float getDimension() {
        return dimension;
    }

    public Chambre() {
        this.type = "Chambre";
    }

    public void setDimension(float dimension) {
        this.dimension = dimension;
    }

    public Chambre(int prix, float dimension, String ref, String localisation, float tauxLoc) {
        super(prix, ref, localisation, tauxLoc);
        this.type = "Chambre";
        this.setDimension(dimension);
    }

    public String affiche() {
        return "Id: " + this.id + " Dimension : " + this.getDimension() + " Localisation : " + this.localisation;
    }

    @Override
    public String afficher() {
        return super.afficher() + "\n Dimension :" + getDimension();
    }

}