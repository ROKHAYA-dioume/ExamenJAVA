public class Client implements IAffiche {
    private int nci;
    private String nomComplet;
    private String email;
    private String adresse;
    private int tel;
    private Reservation[] tableReservation = new Reservation[100];
    private int idReserve = 1;

    public Client(int nci, String nomComplet, String email, String adresse, int tel) {
        setNci(nci);
        setNomComplet(nomComplet);
        setAdresse(adresse);
        setEmail(email);
        setTel(tel);
    }

    public Client() {

    }

    private int nombreDeReservation;

    public int getNombreDeReservation() {
        return nombreDeReservation;
    }

    public int getTel() {
        return tel;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getNomComplet() {
        return nomComplet;
    }

    public void setNomComplet(String nomComplet) {
        this.nomComplet = nomComplet;
    }

    public int getNci() {
        return nci;
    }

    public void setNci(int nci) {
        this.nci = nci;
    }

    public Reservation[] getTableReservation() {
        return this.tableReservation;
    }

    public void setTableReservation(Reservation reserved) {
        this.tableReservation[idReserve] = reserved;
        idReserve++;
    }

    public String affiche() {
        return "- Id: " + this.nci + " Nom Complet : " + this.nomComplet;
    }

    @Override
    public String afficher() {
        return "\n nci : " + getNci() + "\n Nom complet : " + getNomComplet() + "\n Email : " + getEmail()
                + "\n Adresse : " + getAdresse() + "\n Tel : " + getTel();
    }

    @Override
    public boolean equals(Object client) {
        return this.nci == ((Client) client).getNci();
    }

    public void addClient(Reservation reservation) {
        throw new UnsupportedOperationException();
    }

    public void addReservation(Reservation reservation) {
        throw new UnsupportedOperationException();
    }
}
