public class Local implements IAffiche {
    private static int nombreCompte;
    private final int FORMAT = 4;
    private String numero;
    protected String ref;
    protected String localisation;
    protected int prix;
    protected float tauxLoc;
    protected int id;
    protected String type;
    private Reservation[] tableReservation = new Reservation[100];
    private int idReserve = 1;
    private static Validator validator = new Validator();

    public Local(int prix, String localisation, String ref, float tauxLoc) {
        setRef(ref);
        setLocalisation(localisation);
        setPrix(prix);
        setTauxLoc(tauxLoc);
    }

    public static Validator getValidator() {
        return validator;
    }

    public static void setValidator(Validator validator) {
        Local.validator = validator;
    }

    public int cout() {
        return this.prix * (1 + Float.floatToIntBits(this.tauxLoc));
    }

    public String getRef() {
        return this.ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }

    public String getLocalisation() {
        return this.localisation;
    }

    public void setLocalisation(String localisation) {
        this.localisation = localisation;
    }

    public int getTauxLoc() {
        return (int) this.tauxLoc;
    }

    public void setTauxLoc(float tauxLoc) {
        this.tauxLoc = tauxLoc;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrix() {
        return this.prix;
    }

    public void setPrix(int prix) {
        this.prix = prix;
    }

    private String generateNumero() {
        String nombreZero = "";
        String nombreDeCompteString = String.valueOf(++nombreCompte);
        for (int i = 1; i <= (FORMAT - nombreDeCompteString.length()); i++) {
            nombreZero += "0";
        }
        return "REF" + nombreZero + nombreDeCompteString;
    }

    public Local(String localisation2, int i, float j) {
        this.ref = generateNumero();
        this.localisation = localisation2;
        this.prix = i;
        this.tauxLoc = j;
    }

    public String getNumero() {
        return numero;
    }

    public Local(int prix) {
        numero = generateNumero();
        this.setPrix(prix);
    }

    public Local() {
        numero = generateNumero();
    }

    public Reservation[] getTableReservation() {
        return this.tableReservation;
    }

    public void setTableReservation(Reservation reserved) {
        this.tableReservation[idReserve] = reserved;
        idReserve++;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean equals(Object local) {
        return this.ref == ((Local) local).getRef();
    }

    public String afficher() {
        return "\n ref : " + getRef() + "\n Localisation : " + getLocalisation() + "\n prix : " + getPrix()
                + "\n Taux : " + getTauxLoc() + "\n Type de local : " + getType();
    }

    public void addReservation(Reservation reservation) {

    }
}
