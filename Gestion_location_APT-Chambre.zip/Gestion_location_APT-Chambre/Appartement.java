public class Appartement extends Local {
    private int nbrPiece = 3;

    public int getNbrPiece() {
        return nbrPiece;
    }

    public void setNbrPiece(int nbrPiece) {
        this.nbrPiece = nbrPiece;
    }

    public Appartement(String ref, String localisation, int prix, float tauxLoc, int nbrePiece) {
        super(prix, ref, localisation, tauxLoc);
        this.type = "Appartement";
        this.setNbrPiece(nbrePiece);
    }

    public Appartement(String ref, String localisation, int prix, float tauxLoc) {
        super(prix, ref, localisation, tauxLoc);
        this.type = "Appartement";
    }

    public Appartement() {
        this.type = "Appartement";
    }

    public void cout(int montant) {
        

    }

    public String affiche() {
        return "Id: " + this.id + " NbrePiece : " + this.getNbrPiece() + " Localisation : " + this.localisation;
    }

    public String afficher() {
        return super.afficher() + "\n Nombre de piece :" + getNbrPiece();
    }
}
