import java.time.LocalDate;

public class Reservation implements IAffiche {
    private LocalDate date;
    private String duree;
    private Client client;
    private Local local;
    public static int idGenere;
    private String etat;
    private int id;

    public Reservation(LocalDate date, String duree, Client client, Local local) {
        setDate(date);
        setDuree(duree);
        setClient(client);
        setLocal(local);
        this.etat = "disponible";
    }

    public Reservation() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDuree() {
        return this.duree;
    }

    public void setDuree(String duree) {
        this.duree = duree;
    }

    public LocalDate getDate() {
        return this.date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Local getLocal() {
        return this.local;
    }

    public void setLocal(Local local) {
        this.local = local;
    }

    public String getEtat() {
        return this.etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
    }

    public String affiche() {
        return "\n Id : " + getId() + "\n Date : " + getDate() + "\n Duree : " + getDuree() + " mois " + "\n Type : "
                + getLocal().getType();
    }

    @Override
    public String afficher() {
        return "\n Id : " + getId() + "\n Date : " + getDate() + "\n Duree : " + getDuree() + " mois \n Client : "
                + getClient().getNomComplet() + "\n Type : " + getLocal().getType();
    }

}
